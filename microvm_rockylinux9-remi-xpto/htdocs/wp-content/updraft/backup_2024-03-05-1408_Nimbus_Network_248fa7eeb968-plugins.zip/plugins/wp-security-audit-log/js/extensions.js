( function( $ ) {
	$('.lightbox').simpleLightbox({
		showCounter: false
	});
} )( jQuery );
