/**
 * Entry Point for Setup Wizard
 *
 * @since 0.1.0
 */

// Import styles.
// import '../../css/src/mwpal-setup-wizard.scss';
